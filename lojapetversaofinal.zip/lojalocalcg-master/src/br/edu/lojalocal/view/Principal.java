package br.edu.lojalocal.view;

import br.edu.lojalocal.model.Pessoa;

public class Principal {

    public static void main(String[] args) {
        Pessoa p = new Pessoa();
        
       // p.nome = "Ana";
        p.setNome("");
        p.setEmail("ana@anacom");
        p.setPws("");
        
        System.out.println("Erros: " + p.isPessoa(""));
        
        
        
    }

}
