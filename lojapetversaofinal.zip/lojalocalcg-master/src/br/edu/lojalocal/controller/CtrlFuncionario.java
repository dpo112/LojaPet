package br.edu.lojalocal.controller;

import br.edu.lojalocal.dao.FuncionarioDao;
import br.edu.lojalocal.model.Funcionario;
import java.sql.SQLException;

public class CtrlFuncionario {
    FuncionarioDao dao = null;
     
    public void cadastrar(Funcionario funcionario) throws SQLException{
        dao = new FuncionarioDao();
        dao.cadastrar(funcionario);      
    }
    
}
