
package br.edu.lojalocal.controller;

import br.edu.lojalocal.dao.AnimalDao;
import br.edu.lojalocal.dao.FuncionarioDao;
import br.edu.lojalocal.model.Animal;
import java.sql.SQLException;

public class CtrlAnimal {
     AnimalDao dao = null;
     
    public void cadastrar(Animal animal) throws SQLException{
        dao = new AnimalDao();
        dao.cadastrar(animal);      
    }
    
}
