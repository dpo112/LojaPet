package br.edu.lojalocal.controller;

import br.edu.controleendereco.controller.CtrlEndereco;
import br.edu.lojalocal.dao.PessoaDao;
import br.edu.lojalocal.model.Pessoa;
import java.sql.SQLException;

public class CtrlPessoa {
    PessoaDao dao = null;
    CtrlEndereco ctrlEndereco = null;
    
    public void cadastrar(Pessoa pessoa) throws SQLException{
        ctrlEndereco = new CtrlEndereco();
        if (ctrlEndereco.pesquisaCEP(pessoa.getEndereco().getCep()) == null){
           ctrlEndereco.cadastrar(pessoa.getEndereco());
        }  
        dao = new PessoaDao();
        dao.cadastrar(pessoa);      
    }
    
}
