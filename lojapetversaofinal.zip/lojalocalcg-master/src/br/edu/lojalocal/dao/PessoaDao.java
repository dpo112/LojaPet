package br.edu.lojalocal.dao;

import br.edu.lojalocal.model.Pessoa;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PessoaDao extends Conecta {

    private PreparedStatement stman = null;
    private ResultSet result = null;

    public void cadastrar(Pessoa pessoa) throws SQLException {
        String sql = "insert into pessoa (nome, email, pws, numero, complemento, cep)"
                + "values (?,?,?,?,?,?)";
        getConnection();
        stman = connection.prepareStatement(sql);
        stman.setString(1, pessoa.getNome());
        stman.setString(2, pessoa.getEmail());
        stman.setString(3, pessoa.getPws());
        stman.setString(4, pessoa.getNumero());
        stman.setString(5, pessoa.getComplemento());
        stman.setString(6, pessoa.getEndereco().getCep());
        stman.execute();
        stman.close();
        close();

    }

    public long buscarID(String email) throws SQLException {
        String sql = "select id from pessoa where email = ?";
        getConnection();
        stman = connection.prepareStatement(sql);
        stman.setString(1, email);
        result = stman.executeQuery();
        long id = 0;
        if (result.first()){
            id = result.getLong("id");
        }
        result.close();
        stman.close();
        close();
        return id;
    }

}
