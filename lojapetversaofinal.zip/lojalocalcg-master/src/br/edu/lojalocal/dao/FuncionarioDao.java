package br.edu.lojalocal.dao;

import br.edu.lojalocal.controller.CtrlPessoa;
import br.edu.lojalocal.model.Animal;
import br.edu.lojalocal.model.Funcionario;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FuncionarioDao extends PessoaDao{
    private PreparedStatement stman = null;
    
    public void cadastrar(Funcionario funcionario)throws SQLException{
        CtrlPessoa ctrlPessoa = new CtrlPessoa();
        ctrlPessoa.cadastrar(funcionario);
        funcionario.setIdPessoa(super.buscarID(funcionario.getEmail()));
        System.err.println("ID "+ funcionario.getIdPessoa());
        
        String sql = "insert into funcionario (cargo, id_pessoa)"
                + "values (?, ?)";
        getConnection();
        stman = connection.prepareStatement(sql);
        stman.setString(1, funcionario.getCargo());
        stman.setLong(2, funcionario.getIdPessoa());
        stman.execute();
        stman.close();
        close();}

    public void cadastrar(Animal animal) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        

}
