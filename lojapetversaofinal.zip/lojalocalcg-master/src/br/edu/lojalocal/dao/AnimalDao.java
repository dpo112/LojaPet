package br.edu.lojalocal.dao;

import static br.edu.lojalocal.dao.Conecta.connection;
import br.edu.lojalocal.model.Animal;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;



public class AnimalDao {
     private PreparedStatement stman = null;
    private ResultSet result = null;

    public AnimalDao() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }



    public void cadastrar(Animal animal) throws SQLException {
        String sql = "insert into pessoa (nome, especie, raca, peso, sexo)"
                + "values (?,?,?,?,?)";
        getConnection();
        stman = connection.prepareStatement(sql);
        stman.setString(1, animal.getNome());
        stman.setString(2, animal.getEspecie());
        stman.setString(3, animal.getRaca());
        stman.setString(4, animal.getPeso());
        stman.setString(5, animal.getSexo());
        stman.execute();
        stman.close();
        close();

    }

    public long buscarID(String email) throws SQLException {
        String sql = "select id from pessoa where email = ?";
        getConnection();
        stman = connection.prepareStatement(sql);
        stman.setString(1, email);
        result = stman.executeQuery();
        long id = 0;
        if (result.first()){
            id = result.getLong("id");
        }
        result.close();
        stman.close();
        close();
        return id;
}

    private void getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void close() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
