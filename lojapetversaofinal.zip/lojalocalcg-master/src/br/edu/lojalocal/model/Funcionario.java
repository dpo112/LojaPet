package br.edu.lojalocal.model;

public class Funcionario extends Pessoa {

    private long id;
    private String cargo;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public void isFuncionario(String confSenha) throws Exception {
        String erros = isPessoa(confSenha);

        if (cargo.equals("")) {
            erros += "Cargo em branco!\n";
        }

        if (!erros.equals("")) {
            throw new Exception(erros);
        }
    }

}
