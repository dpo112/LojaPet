package br.edu.lojalocal.model;

import br.edu.controleendereco.model.Endereco;

public class Pessoa {

    private long idPessoa;
    private String nome;
    private String email;
    private String pws;
    private String numero;
    private String complemento;
    
    private Endereco endereco;

    public Pessoa() {
        endereco = new Endereco();
    }

    public String isPessoa(String pwsconf) {
        String erros = "";
        if (nome.equals("")) {
            erros += "Nome em branco.\n";
        }

        if (email.equals("")) {
            erros += "E-mail em branco.\n";
        } else if (!email.contains("@") || email.indexOf(".") == -1) {
            erros += "Email invalido!\n";
        }

        if (pws.equals("")) {
            erros += "Senha em branco.\n";
        } else if (pws.length() < 6) {
            erros += "Senha(s) muito curta! Minimo de 6 caracteres.\n";
        } else if (!pws.equals(pwsconf)) {
            erros += "Senhas diferentes!\n";
        }

        return erros + endereco.isEndereco();
    }

    //GETs e SETs

    public long getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(long idPessoa) {
        this.idPessoa = idPessoa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPws() {
        return pws;
    }

    public void setPws(String pws) {
        this.pws = pws;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }   
    
}
