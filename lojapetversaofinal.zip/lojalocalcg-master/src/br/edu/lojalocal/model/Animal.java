package br.edu.lojalocal.model;

import br.edu.controleendereco.model.Endereco;

public class Animal {

    private long idAnimal;
    private String nome;
    private String especie;
    private String raca;
    private String peso;
    private String sexo;
    private long idPessoa;
    

    public Animal() {
       
    }

    public String isPessoa(String pwsconf) {
        String erros = "";
        if (nome.equals("")) {
            erros += "Nome em branco.\n";
        }

         if (especie.equals("")) {
            erros += "especie em branco.\n";
        }

         if (raca.equals("")) {
            erros += "raça em branco.\n";
        }
         
          if (peso.equals("")) {
            erros += "peso em branco.\n";
        }
          
           if (sexo.equals("")) {
            erros += "sexo em branco.\n";
        }
        return null;
    }

    //GETs e SETs

    public long getIdAnimal() {
        return idAnimal;
    }

    public void setIdAnimal(long idAnimal) {
        this.idAnimal = idAnimal;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
}

    
