# Loja Local
Para Cadastro e Pesquisa feita em JAVA SE
